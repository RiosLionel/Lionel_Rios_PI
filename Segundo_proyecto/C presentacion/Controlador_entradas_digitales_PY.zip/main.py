from machine import Pin
import time

#conf. pin led
led = Pin(5, Pin.OUT)

#conf. boton
pulsador = Pin(14, Pin.IN, Pin.PULL_UP)

#bucle
while True:
    if pulsador.value() == 0:
        led.value(1)
    else:
        led.value(0)

    time.sleep(0.1)

 


